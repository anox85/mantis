#ifndef DEF_EDITEUR
#define DEF_EDITEUR
    int gagne(int lettreTrouvee[], long tailleMot);
    int rechercheLettre(char lettre, char motSecret[], int lettreTrouvee[]);


#endif

#ifndef COLLISION_H_
#define COLLISION_H_
struct AABB
{
int x;
int y;
int w;
int h;
}; typedef struct AABB rect_objet;

 struct cercle
{
 int X1;
 int Y1;
 int R;
};typedef struct cercle cercle_objet;



int collision (SDL_Rect personnage,rect_objet objet);
int collision_trigo (SDL_Rect personnage,SDL_Rect objet,cercle_objet inscrit,cercle_objet objet_inscrit);

#endif

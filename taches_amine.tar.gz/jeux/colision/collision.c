#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include "collision.h"

int collision (SDL_Rect personnage,rect_objet objet)
{  
if ((personnage.x+personnage.w<objet.x)||(personnage.x>objet.x+objet.w)||(personnage.x+personnage.w<objet.x)||(personnage.x>objet.x+objet.w))
return 0;
else
return 1;
}

#ifndef DEF_EDITEUR
#define DEF_EDITEUR
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
long nombreAleatoire(long nombreMax);
int gagne(int lettreTrouvee[], long tailleMot);
void jouer(SDL_Surface *ecran);
int rechercheLettre(char lettre, char motSecret[], int lettreTrouvee[]);
int piocheMot(char *motPioche);

#endif

#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <time.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include "head.h"

int piocheMot(char *motPioche)
{
FILE *fichier = NULL;
int caractereActuel =0;
long nombreMot = 0;
long numMot=0;
fichier = fopen("dico.txt","r");

do
{
    caractereActuel = fgetc(fichier);
    if(caractereActuel == '\n')
        nombreMot ++;
}while(caractereActuel != EOF);

numMot = nombreAleatoire(nombreMot);
rewind(fichier);
while(numMot>0)
{
    caractereActuel = fgetc(fichier);
    if(caractereActuel == '\n')
        numMot --;
}
fgets(motPioche, 20, fichier);
motPioche[strlen(motPioche) - 1] = '\0';
fclose(fichier);

return 1;
}



long nombreAleatoire(long nombreMax)
{
    srand(time(NULL));
    return (rand() % nombreMax);
}


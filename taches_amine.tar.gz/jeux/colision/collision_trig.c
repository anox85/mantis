#include<stdio.h>
#include"SDL/SDL.h"
#include"collision.h"
#include"math.h"




int collision_trigo (SDL_Rect personnage,SDL_Rect objet,cercle_objet inscrit,cercle_objet objet_inscrit)
{   float D1;
    float D2;
   
   inscrit.X1=personnage.x+personnage.w/2;
   inscrit.Y1=personnage.y+personnage.h/2;
   if (personnage.w<personnage.h)
   {
     inscrit.R=personnage.w/2;
   }
  else
     inscrit.R=personnage.h/2;
   
   objet_inscrit.X1=objet.x+objet.w/2;
   objet_inscrit.Y1=objet.y+objet.h/2;
   if (objet.w<objet.h)
   {
     objet_inscrit.R=objet.w/2;
   }
  else
     objet_inscrit.R=objet.h/2;
   
   D1=sqrt(pow(personnage.x-objet.x,2)+pow(personnage.y-objet.y,2));
   D2=inscrit.R+objet_inscrit.R;
  if (D1!=D2)
  return 0;
  else
  return 1;
   
  
}

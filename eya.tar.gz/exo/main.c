#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

#include <SDL/SDL_image.h>
#include "head.h"


int main(int argc, char *argv[])
{
//VARIABLES*********************************************************************
    SDL_Surface *ecran = NULL, *fondMenu=NULL;
    SDL_Event event;                        SDL_Rect posFond;
    int quit =1;                            posFond.x=0;
                                            posFond.y=0;

//INIT**************************************************************************
    SDL_Init(SDL_INIT_VIDEO);
    SDL_WM_SetIcon(IMG_Load("debut.jpg"), NULL);
    ecran = SDL_SetVideoMode(400, 500, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Pendu", NULL);
    fondMenu = IMG_Load("debut1.jpg");


//BOUCLE DU MENU****************************************************************
while (quit)
{
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                quit = 0;
                break;
            case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_KP1:
                        jouer(ecran);
                        break;
                    case SDLK_ESCAPE:
                        quit=0;
                        break;
                    case SDLK_KP2:
                        quit=0;
                        break;
                }
                break;
        }




    SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
    SDL_BlitSurface(fondMenu, NULL,ecran,&posFond);
    SDL_Flip(ecran);

}

    SDL_FreeSurface(fondMenu);
    SDL_Quit();

    return EXIT_SUCCESS;
}

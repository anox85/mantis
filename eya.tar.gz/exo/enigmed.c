#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <ctype.h>
#include "head.h"

void jouer(SDL_Surface *ecran)
{
//VARIABLES*********************************************************************
TTF_Font *police=NULL;
SDL_Color couleurNoire = {0, 0, 0};
police = TTF_OpenFont("arial.ttf", 20);
char motSecret[30]={0};
int continuer =1;
SDL_Event event;
int *lettreTrouvee=NULL;
int nombreLettre=0;
int i=0;
SDL_Surface *texte1=NULL, *texte2=NULL;
SDL_Color couleur={0,0,0};
char afficheMot[20]={0};
char cara = 0;
char lettre = 0;
SDL_Rect posTexte1;
posTexte1.x=20;
posTexte1.y=100;
SDL_Rect posTexte2;
posTexte2.x=20;
posTexte2.y=200;
int coupRestant =7;
SDL_Surface *dessinPendu[7]={NULL};
SDL_Rect posDessinPendu;
posDessinPendu.x=50;
posDessinPendu.y=250;
int go=0;

//INITIALISATION****************************************************************
TTF_Init();
if(!piocheMot(&motSecret))
exit(EXIT_FAILURE);
nombreLettre =strlen(motSecret);
lettreTrouvee = malloc (nombreLettre * sizeof(int));
police = TTF_OpenFont("arial.ttf",20);

dessinPendu[0]=IMG_Load("pendu0.png");
dessinPendu[6]=IMG_Load("pendu1.png");
dessinPendu[5]=IMG_Load("pendu2.png");
dessinPendu[4]=IMG_Load("pendu3.png");
dessinPendu[3]=IMG_Load("pendu4.png");
dessinPendu[2]=IMG_Load("pendu5.png");
dessinPendu[1]=IMG_Load("pendu6.png");


texte1=TTF_RenderText_Blended(police,"Quel est le mot secret ?",couleur);
SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
SDL_BlitSurface(texte1, NULL,ecran,&posTexte1);
SDL_BlitSurface(dessinPendu[0],NULL,ecran,&posDessinPendu);
SDL_Flip(ecran);



 for (i = 0 ; i < nombreLettre ; i++){
        lettreTrouvee[i] = 0;}


//BOUCLE ATENTE LETTRE**********************************************************

while((continuer==1) &&(coupRestant > 0 )&& (!gagne(lettreTrouvee, nombreLettre)))
{
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                cara = event.key.keysym.sym;
                lettre =cara;
                go =1;
                break;
        }
    //petite conversion qwerty->azerty
    switch (cara)
        {
            case 'q' :
            lettre ='a';
            break;
            case ';' :
            lettre ='m';
            break;
            case 'z' :
            lettre ='w';
            break;
            case 'a' :
            lettre = 'q';
            break;
            case 'w' :
            lettre ='z';
            break;
        }
        lettre = toupper(lettre); //majuscule
 if(go==1){
        SDL_FreeSurface(texte2);
        SDL_FreeSurface(texte1);
        if (!rechercheLettre(lettre, motSecret, lettreTrouvee))
            {
                coupRestant--; // On enl�ve un coup au joueur
            }

         for (i = 0 ; i < nombreLettre ; i++)
            {
                if (lettreTrouvee[i]) // Si on a trouv� la lettre n�i
                    afficheMot[i]=motSecret[i];
                else
                    afficheMot[i]='-';

            }

        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
        texte2=TTF_RenderText_Blended(police,afficheMot,couleur);
        SDL_BlitSurface(dessinPendu[coupRestant],NULL,ecran,&posDessinPendu);
        texte1=TTF_RenderText_Blended(police,"Quel est le mot secret ?",couleur);

        SDL_BlitSurface(texte1, NULL,ecran,&posTexte1);
        SDL_BlitSurface(texte2, NULL,ecran,&posTexte2);
        SDL_Flip(ecran);
        go =0;

         }
}
while((continuer==1) )
{

        SDL_FreeSurface(texte2);
        SDL_FreeSurface(texte1);
        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));
    if (gagne(lettreTrouvee, nombreLettre)){
        texte1=TTF_RenderText_Blended(police,"GAGNE le mot secret etait bien :",couleur);
        texte2=TTF_RenderText_Blended(police,motSecret,couleur);}

    else{
        texte1=TTF_RenderText_Blended(police,"PERDU le mot secret etait :",couleur);
        texte2=TTF_RenderText_Blended(police,motSecret,couleur);}


        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
            case SDL_KEYDOWN:
                continuer = 0;
                break;
        }
    SDL_BlitSurface(texte1, NULL,ecran,&posTexte1);
    SDL_BlitSurface(texte2, NULL,ecran,&posTexte2);
    SDL_BlitSurface(dessinPendu[1],NULL,ecran,&posDessinPendu);
    SDL_Flip(ecran);

}
free(lettreTrouvee);
SDL_FreeSurface(texte1);
SDL_FreeSurface(texte2);
for(i=0;i<7;i++){
    SDL_FreeSurface(dessinPendu[i]);}
TTF_CloseFont(police);
TTF_Quit();
}


int gagne(int lettreTrouvee[], long tailleMot)
{
    long i = 0;
    int joueurGagne = 1;

    for (i = 0 ; i < tailleMot ; i++)
    {
        if (lettreTrouvee[i] == 0)
            joueurGagne = 0;
    }

    return joueurGagne;
}
int rechercheLettre(char lettre, char motSecret[], int lettreTrouvee[])
{
    long i = 0;
    int bonneLettre = 0;

    // On parcourt motSecret pour v�rifier si la lettre propos�e y est
    for (i = 0 ; motSecret[i] != '\0' ; i++)
    {
        if (lettre == motSecret[i]) // Si la lettre y est
        {
            bonneLettre = 1; // On m�morise que c'�tait une bonne lettre
            lettreTrouvee[i] = 1; // On met � 1 le case du tableau de bool�ens correspondant � la lettre actuelle
        }
    }

    return bonneLettre;
}
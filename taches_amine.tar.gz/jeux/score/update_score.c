#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include "update_score.h"
#include "collision.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
void gestion_temps (SDL_Surface *ecran)
{int t1=0,t2=0;
char chrono[20];
SDL_Surface *texte;
TTF_Font *police;
SDL_Color rouge={255,0,0};
SDL_Color blanc={255,255,255};
TTF_Init();
  police = TTF_OpenFont("DFTEH.ttf", 50); 
  t1 = SDL_GetTicks();

 
t2 = SDL_GetTicks() - t1;         //Minute       //Seconde   //Dixieme
    sprintf(chrono, "%02u:%02u.%u  ", t2/1000/60%60, t2/1000%60, t2%1000/100);
    texte = TTF_RenderText_Shaded(police, chrono, rouge,blanc);
 
    SDL_BlitSurface(texte, NULL, ecran, 0);
TTF_CloseFont (police); 
SDL_FreeSurface(texte) ;    
}
int gestion_score  (SDL_Rect personnage,rect_objet alphabet)
{int score=0;
    
            if (collision( personnage, alphabet)==1)
         {
             score+=100;
             return score;
         }
     return score;   
    
}
int gestion_vies (SDL_Rect personnage,rect_objet ennemie)
{ int vies=0,i=0;
  
  if (collision ( personnage, ennemie)==1)
  { 
    vies--;
    return vies;
  }
 return vies;
 }

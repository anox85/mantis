#ifndef UPDATE_SCORE_H
#define UPDATE_SCORE_H_
#include "collision.h"

void gestion_temps ();
int gestion_score  (SDL_Rect personnage,rect_objet alphabet);
int gestion_vies (SDL_Rect personnage,rect_objet ennemie);
#endif

#ifndef OBJET_H_
#define OBJET_H_
void initialisation(SDL_Rect positionimage);
int affichage_objet(SDL_Surface *screen, SDL_Surface *image,SDL_Rect positionimage,char alphabet[20],int posx,int posy);
char chargermot(char fichier[20]);
void distribution (SDL_Surface *screen,char fichier[20]);
#endif

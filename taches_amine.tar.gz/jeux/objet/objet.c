#include <stdio.h>
#include <stdlib.h>
#include "SDL/SDL.h"
#include "SDL/SDL_image.h"
#include "SDL/SDL_ttf.h"
#include "objet.h"
#include <string.h>
void initialisation(SDL_Rect positionimage)
{       positionimage.x=0;
        positionimage.y=0;
        positionimage.h=0;
        positionimage.w=0;
}
int affichage_objet(SDL_Surface *screen, SDL_Surface *image,SDL_Rect positionimage,char alphabet[20],int posx,int posy)
{
        positionimage.x=posx;
        positionimage.y=posy;
        image = IMG_Load(alphabet);

        SDL_BlitSurface(image , NULL , screen  , &positionimage);
        if(screen==NULL)
        {
            printf("unabble to set video mode :%s\n",SDL_GetError());
            return 1;
        }

        SDL_Flip(screen);
}


char chargermot(char fichier[20]) 
{ 
FILE* f = NULL; 
int ligne; 
int i = 0; 
char mot;  
ligne = rand(); 
f = fopen(fichier, "r"); 
if (f == NULL) 
printf("error \n"); 
else 
{ 
mot = fgetln(fichier, ligne); 
fclose(f); 
return mot; 
}}
void distribution (SDL_Surface *fonds,char fichier[20])
{ char mot[20];
   TTF_Font *police;
   SDL_Color rouge={255,0,0};
   SDL_Color blanc={255,255,255};
   TTF_Init();
   police = TTF_OpenFont("DFTEH.ttf", 50); 
   strcpy(mot,chargermot(fichier));
   char a,b,c,d,e;
   SDL_Rect pos;
   SDL_Surface *a1;
   SDL_Surface *a2;
   SDL_Surface *a3;
   SDL_Surface *a4;
   SDL_Surface *a5;
  if (strcmp("mkdir",mot)==0)
{  a='m'; b='i'; c='k';d='d';e='r';
    a1 = TTF_RenderText_Blended(police,a, blanc);
    pos.x=279; pos.y=203;
    SDL_BlitSurface(a1, NULL,fonds,&pos);
    a2 = TTF_RenderText_Blended(police,b, rouge);
    pos.x=447; pos.y=317;
    SDL_BlitSurface(a2, NULL,fonds,&pos);
    a3 = TTF_RenderText_Blended(police,c, blanc);
    pos.x=2762; pos.y=422;
    SDL_BlitSurface(a3, NULL,fonds,&pos);
    a4 = TTF_RenderText_Blended(police,d, blanc);
    pos.x=4092; pos.y=249;
    SDL_BlitSurface(a4, NULL,fonds,&pos);
    a5 = TTF_RenderText_Blended(police,e, blanc);
    pos.x=6530; pos.y=306;
    SDL_BlitSurface(a5, NULL,fonds,&pos);
}
  else if (strcmp("touch",mot)==0)
{a='o'; b='u'; c='h';d='c';e='t';
    a1 = TTF_RenderText_Blended(police,a, blanc);
    pos.x=279; pos.y=203;
    SDL_BlitSurface(a1, NULL,fonds, &pos);
    a2 = TTF_RenderText_Blended(police,b, rouge);
    pos.x=447; pos.y=317;
    SDL_BlitSurface(a2, NULL,fonds, &pos);
    a3 = TTF_RenderText_Blended(police,c, blanc);
    pos.x=2762; pos.y=422;
    SDL_BlitSurface(a3, NULL,fonds, &pos);
    a4 = TTF_RenderText_Blended(police,d, blanc);
    pos.x=4092; pos.y=249;
    SDL_BlitSurface(a4, NULL,fonds, &pos);
    a5 = TTF_RenderText_Blended(police,e, blanc);
    pos.x=6530; pos.y=306;
    SDL_BlitSurface(a5, NULL,fonds,&pos);
}
  else if (strcmp("gedit",mot)==0)
{
    a='e'; b='g'; c='i';d='d';e='t';
    a1 = TTF_RenderText_Blended(police,a, blanc);
    pos.x=279; pos.y=203;
    SDL_BlitSurface(a1, NULL,fonds, &pos);
    a2 = TTF_RenderText_Blended(police,b, rouge);
    pos.x=447; pos.y=317;
    SDL_BlitSurface(a2, NULL,fonds, &pos);
    a3 = TTF_RenderText_Blended(police,c, blanc);
    pos.x=2762; pos.y=422;
    SDL_BlitSurface(a3, NULL,fonds, &pos);
    a4 = TTF_RenderText_Blended(police,d, blanc);
    pos.x=4092; pos.y=249;
    SDL_BlitSurface(a4, NULL,fonds, &pos);
    a5 = TTF_RenderText_Blended(police,e, blanc);
    pos.x=6530; pos.y=306;
    SDL_BlitSurface(a5, NULL,fonds, &pos);
}
}



